package com.example.ricardo.projetointegrador;

import java.util.ArrayList;

public class GeradorFilmes {

	public static ArrayList<FilmeModelo> gerarFilmes(int quantidade, String nome){
		ArrayList<FilmeModelo> lista = new ArrayList<>(quantidade);

		for (int i=1; i < quantidade; i++) {
			lista.add(new FilmeModelo(nome + i));
		}

		return lista;
	}
}
