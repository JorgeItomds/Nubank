package com.example.ricardo.projetointegrador;

public class FilmeModelo {

	private String titulo;

	public FilmeModelo(String titulo) {
		this.titulo = titulo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo (String titulo) {
		this.titulo = titulo;
	}
}
