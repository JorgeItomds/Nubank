package com.example.ricardo.projetointegrador;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class HomeActivity extends AppCompatActivity {


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		inicializarLayout();
	}

	public void inicializarLayout(){
		ViewPager viewPager = findViewById(R.id.viewpager);
		TabLayout tabs = findViewById(R.id.tabs);

   		viewPager.setAdapter(new MyViewPagerAdapter(this));
		tabs.setupWithViewPager(viewPager);

	}
	public void voltalogin (View view){
		Intent vltlogin = new Intent(this, MainActivity.class);
		startActivity(vltlogin);
	}
	public void detalhefilme(View view){
		Intent detfilme = new Intent(this, DetalheFilmeActivity.class);
		startActivity(detfilme);
	}

}
