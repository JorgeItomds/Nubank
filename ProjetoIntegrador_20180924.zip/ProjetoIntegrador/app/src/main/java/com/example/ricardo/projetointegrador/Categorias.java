package com.example.ricardo.projetointegrador;

import java.util.ArrayList;

public class Categorias {
    public static ArrayList<FilmeModelo> tipocategoria(int quantidade){
        ArrayList<FilmeModelo> categoriaFilme = new ArrayList<>(quantidade);

        categoriaFilme.add(new FilmeModelo("Ação"));
        categoriaFilme.add(new FilmeModelo("Aventura"));
        categoriaFilme.add(new FilmeModelo("Terror"));
        categoriaFilme.add(new FilmeModelo("Suspense"));


        return categoriaFilme;
    }


}
