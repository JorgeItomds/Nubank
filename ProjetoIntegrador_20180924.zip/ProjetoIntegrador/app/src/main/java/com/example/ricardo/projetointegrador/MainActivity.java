package com.example.ricardo.projetointegrador;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    public void logIn (View view){
        Intent telalogin = new Intent(this, HomeActivity.class);
        startActivity(telalogin);

    }

    public void recuperarSenha(View view){
        Intent recsenha = new Intent(this,EsqueciSenhaActivity.class);
        startActivity(recsenha);
    }

    public void registrar (View view){
        Intent rec = new Intent(this,EsqueciSenhaActivity.class);
        startActivity(rec);
    }



}
